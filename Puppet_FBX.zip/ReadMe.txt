-기본적으로 사용할 목각인형 : puppet_Tpose.fbx [obj 형태의 파일도 있습니다.]

-해당 파일에 mixamo animation 올려져 있는 예시 : Jumping Down.fbx

-man[연구실에 있는 목각인형에 조금 더 가까운 형태의 obj 파일로 예비 후보입니다.]
